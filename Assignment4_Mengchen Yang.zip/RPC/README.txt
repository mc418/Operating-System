
There are two processes, and use rpc to transfer data between client and server.

Executing steps: 

>make
>./server
>./client localhost